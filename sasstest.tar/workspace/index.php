<?php


if (isset($_POST['mode']) && $_POST['mode'] === 'sass_edit') {
	
	file_put_contents(dirname(__FILE__).'/styles/default.sass', $_POST['code']);
	
	$sass_path = dirname(__FILE__).'/styles/default.sass';
	$css_path = dirname(__FILE__).'/styles/default.css';
	$command = "sass ".$sass_path.":". $css_path;
	
	exec($command);
}



if (isset($_POST['mode']) && $_POST['mode'] === 'html_edit') {
	file_put_contents(dirname(__FILE__).'/page.html', $_POST['code']);
}



$sass_code = "";
if (file_exists( dirname(__FILE__).'/styles/default.sass')) {
	$sass_code = file_get_contents(dirname(__FILE__).'/styles/default.sass');
}

$html_code = "";
if (file_exists( dirname(__FILE__).'/styles/default.sass')) {
	$html_code = file_get_contents(dirname(__FILE__).'/page.html');
}



?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>SASS compiler</title>
</head>
<body>
	<h1>HTML</h1>
	
	<div>
<form action="/index.php" method="post">
<textarea id="html_code" name="code" rows="10" cols="30"><?php echo $html_code; ?></textarea>
<input type="hidden" name="mode" value="html_edit"/>
<button>submit</button>
</form>
	</div>

	<h1>SASS</h1>
	<div>
<form action="/index.php" method="post">
<textarea id="sass_code" name="code" rows="10" cols="30"><?php echo $sass_code; ?></textarea>
<input type="hidden" name="mode" value="sass_edit"/>
<button>submit</button>
</form>
	</div>

<div>
<a href='/page.html' target='_blank'>show page</a>
</div>


</body>
</html>
